ETF_TICKERS = ['AIAI.MI', 'BATT.MI', 'ECAR.MI',
               'SWDA.MI', 'USPY.DE', 'WHEA.MI',
               'YODA.MI', '2B77.DE', 'ESPO.MI',
               'IWVL.MI', 'QDVE.DE']

STOCK_TICKERS = ['TIT.MI', 'TL0.DE']

CRYPTO_TICKERS = ['ADA-EUR', 'BTC-EUR', 'CRO-EUR',
                  'ETH-EUR', 'FET-EUR']