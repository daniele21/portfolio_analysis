# OPTIMIZATIONS
RISK_FREE_RATE = 0.03

# VISUALIZATION
TOOLS = 'pan,wheel_zoom,hover,reset,save,crosshair'
