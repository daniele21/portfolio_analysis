DATA_DIR = 'resources'
OUTPUT_DIR = 'output'

# TRANSACTION_PATH = f'{DATA_DIR}/transactions.csv'
PERFORMANCE_REPORT_DIR = f'{OUTPUT_DIR}/performance'

# TRANSACTION_PATH = 'resources/transactions.json'

TICKER_DATA_DIR = 'resources/tickers'
TICKER_DETAILS_PATH = f'{TICKER_DATA_DIR}/tickers_details.csv'
TICKER_DETAILS_JSON_PATH = f'resources/my_tickers.json'

TRANSACTION_PATH = 'resources/portfolio/transactions.csv'
TRANSACTION_JSON_PATH = 'resources/my_transactions.json'

