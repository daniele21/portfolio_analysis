from setuptools import setup, find_packages

from portfolio_analysis.version import __version__


def load_requirements():
    with open('requirements.txt', 'r') as req_file:
        requirements = req_file.read().split('\n')
        req_file.close()

    return requirements


def release_version():
    setup(
        name="portfolio_analysis",
        packages=find_packages(),
        package=['portfolio_analysis'],
        include_package_data=True,
        version=__version__,
        install_requires=load_requirements(),
        url='https://github.com/daniele21/portfolio_analysis',
        description="All you need to analyze you portfolio is this tool: Portfolio Analysis",
        long_description_content_type="text/markdown",
        author="Daniele Moltisanti",
        author_email="danielemoltisanti@live.it",
        license="MIT Licence",
        keywords="portfolio finance analysis optimization"
    )


if __name__ == '__main__':
    release_version()
